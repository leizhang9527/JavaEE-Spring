package com.bittech.jdbc.biz;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Author: secondriver
 * Created: 2018/6/18
 */
public class MemoGroupJdbcImpl implements MemoGroupJdbc {
    
    private final JdbcComponent jdbcComponent;
    
    public MemoGroupJdbcImpl(JdbcComponent jdbcComponent) {
        this.jdbcComponent = jdbcComponent;
    }
    
    @Override
    public int insetMemoGroup(MemoGroup memoGroup) {
        if (memoGroup == null || memoGroup.getName() == null || memoGroup.getCreatedTime() == null) {
            return 0;
        }
        Connection connection = this.jdbcComponent.getConnection();
        String sql = "insert into memo_group (name,created_time) values (?,?)";
        PreparedStatement statement = this.jdbcComponent.getPreparedStatement(connection, sql);
        if (statement == null) {
            return 0;
        }
        try {
            statement.setString(1, memoGroup.getName());
            statement.setDate(2,
                    new java.sql.Date(memoGroup.getCreatedTime().getTime()
                    ));
            
            return this.jdbcComponent.executeUpdate(statement);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.jdbcComponent.destroyResource(null, statement, connection);
        }
        return 0;
    }
    
    @Override
    public int updateMemoGroup(int id, String name) {
        if (name == null) {
            return 0;
        }
        Connection connection = this.jdbcComponent.getConnection();
        String sql = "update memo_group set name=? where id=?";
        PreparedStatement statement = this.jdbcComponent.getPreparedStatement(connection, sql);
        try {
            statement.setString(1, name);
            statement.setInt(2, id);
            
            return statement.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            
            this.jdbcComponent.destroyResource(null, statement, connection);
        }
        
        return 0;
    }
    
    @Override
    public List<MemoGroup> queryMemoGroup(int id) {
        List<MemoGroup> memoGroups = new ArrayList<>();
        Connection connection = this.jdbcComponent.getConnection();
        String sql = "select id, name,created_time,modify_time from memo_group where id =? ";
        PreparedStatement statement = this.jdbcComponent.getPreparedStatement(connection, sql);
        ResultSet resultSet = null;
        try {
            statement.setInt(1, id);
            resultSet = statement.executeQuery();
            memoGroups = this.handleResultSet(resultSet);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.jdbcComponent.destroyResource(resultSet, statement, connection);
        }
        return memoGroups;
    }
    
    @Override
    public List<MemoGroup> queryMemoGroupByCreatedTime(LocalDateTime startTime, LocalDateTime endTime) {
        List<MemoGroup> memoGroups = new ArrayList<>();
        Connection connection = this.jdbcComponent.getConnection();
        String sql = "select id, name,created_time,modify_time from memo_group where created_time between ? and ? ";
        PreparedStatement statement = this.jdbcComponent.getPreparedStatement(connection, sql);
        ResultSet resultSet = null;
        try {
            statement.setDate(1, Date.valueOf(startTime.toLocalDate()));
            statement.setDate(2, Date.valueOf(endTime.toLocalDate()));
            resultSet = statement.executeQuery();
            memoGroups = this.handleResultSet(resultSet);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.jdbcComponent.destroyResource(resultSet, statement, connection);
        }
        return memoGroups;
    }
    
    @Override
    public int deleteMemoGroup(int id) {
        Connection connection = this.jdbcComponent.getConnection();
        String sql = "delete from  memo_group  where id=?";
        PreparedStatement statement = this.jdbcComponent.getPreparedStatement(connection, sql);
        try {
            statement.setInt(1, id);
            return statement.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            
            this.jdbcComponent.destroyResource(null, statement, connection);
        }
        return 0;
    }
    
    
    private List<MemoGroup> handleResultSet(ResultSet resultSet) throws SQLException {
        List<MemoGroup> memoGroups = new ArrayList<>();
        if (resultSet != null) {
            
            while (resultSet.next()) {
                MemoGroup memoGroup = new MemoGroup();
                memoGroup.setId(resultSet.getInt("id"));
                memoGroup.setName(resultSet.getString("name"));
                memoGroup.setCreatedTime(resultSet.getDate("created_time"));
                memoGroup.setModifyTime(resultSet.getTimestamp("modify_time"));
                memoGroups.add(memoGroup);
            }
        }
        return memoGroups;
    }
}

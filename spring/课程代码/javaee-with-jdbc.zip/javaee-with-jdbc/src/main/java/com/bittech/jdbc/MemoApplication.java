package com.bittech.jdbc;

import com.bittech.jdbc.biz.JdbcComponent;
import com.bittech.jdbc.biz.MemoGroup;
import com.bittech.jdbc.biz.MemoGroupJdbc;
import com.bittech.jdbc.biz.MemoGroupJdbcImpl;

import java.util.List;

/**
 * * Author: secondriver
 * * Created: 2018/6/23
 */
public class MemoApplication {
    
    public static void main(String[] args) {
        System.out.println("Hello JDBC");
        JdbcComponent jdbcComponent = new JdbcComponent("com.mysql.jdbc.Driver", "jdbc:mysql://localhost:3306/memo?user=root&password=root&useSSL=true");
        MemoGroupJdbc memoGroupJdbc = new MemoGroupJdbcImpl(jdbcComponent);
        List<MemoGroup> memoGroupList = memoGroupJdbc.queryMemoGroup(1);
        System.out.println(memoGroupList);
    }
}
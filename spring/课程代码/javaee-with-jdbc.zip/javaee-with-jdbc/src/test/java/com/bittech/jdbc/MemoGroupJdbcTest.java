package com.bittech.jdbc;

import com.bittech.jdbc.biz.JdbcComponent;
import com.bittech.jdbc.biz.MemoGroup;
import com.bittech.jdbc.biz.MemoGroupJdbc;
import com.bittech.jdbc.biz.MemoGroupJdbcImpl;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

/**
 * Author: secondriver
 * Created: 2018/6/18
 */
@FixMethodOrder(value = MethodSorters.NAME_ASCENDING)
public class MemoGroupJdbcTest {
    
    private JdbcComponent jdbcComponent = new JdbcComponent("com.mysql.jdbc.Driver",
            "jdbc:mysql://localhost:3306/memo?user=root&password=root");
    
    private MemoGroupJdbc memoGroupJdbc = new MemoGroupJdbcImpl(jdbcComponent);
    
    @Test
    public void test1_InsetMemoGroup() {
        MemoGroup memoGroup = new MemoGroup();
        memoGroup.setName("JDBC-M");
        memoGroup.setCreatedTime(new Date());
        int effect = memoGroupJdbc.insetMemoGroup(memoGroup);
        System.out.println("Test-Result " + (effect == 1));
    }
    
    @Test
    public void test2_UpdateMemoGroup() {
        int effect = memoGroupJdbc.updateMemoGroup(3, "JDBC-P");
        System.out.println("Test-Result " + (effect == 1));
    }
    
    @Test
    public void test3_QueryMemoGroup() {
        List<MemoGroup> memoGroupList = memoGroupJdbc.queryMemoGroup(3);
        System.out.println(memoGroupList);
        System.out.println("Test-Result " + (!memoGroupList.isEmpty()));
    }
    
    @Test
    public void test4_QueryMemoGroupByCreatedTime() {
        LocalDateTime start=LocalDateTime.now();
        LocalDateTime end = start.plusHours(1);
        
        List<MemoGroup> memoGroupList =
                memoGroupJdbc.queryMemoGroupByCreatedTime(start,end);
        System.out.println(memoGroupList);
        System.out.println("Test-Result " + (memoGroupList.isEmpty()));
        
    }
    
    @Test
    public void test5_DeleteMemoGroup() {
        int effect = memoGroupJdbc.deleteMemoGroup(3);
        System.out.println("Test-Result " + (effect == 1));
    }
    
}

package com.bittech.springcore.assemble;

/**
 * Author: secondriver
 * Created: 2018/10/31
 */
public class Bar {
}

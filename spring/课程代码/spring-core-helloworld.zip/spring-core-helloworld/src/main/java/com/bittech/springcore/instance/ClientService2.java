package com.bittech.springcore.instance;

/**
 * Author: secondriver
 * Created: 2018/10/31
 */
public class ClientService2 {
    
    public ClientService3 getClientService3() {
        return new ClientService3();
    }
    
}

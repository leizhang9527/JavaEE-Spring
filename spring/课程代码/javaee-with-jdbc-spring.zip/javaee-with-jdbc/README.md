## JavaEE课程中JDBC章节示例项目

### 技术栈

+ JavaSE中JDBC API
+ 单元测试
+ Maven打包

### 依赖项

+ MySQL数据库
+ 便签应用

### 案例说明

+ src/main/java表示业务源码
  + com.bittech.jdbc.biz包中归档代码
  + com.bittech.jdbc.MemoApplication入口程序
+ src/test/java表示测试源码

### 功能说明

+ 便签分组表的CRUD操作
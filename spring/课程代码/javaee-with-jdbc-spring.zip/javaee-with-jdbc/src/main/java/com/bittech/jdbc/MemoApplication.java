package com.bittech.jdbc;

import com.bittech.jdbc.biz.MemoGroup;
import com.bittech.jdbc.biz.MemoGroupJdbc;
import com.bittech.jdbc.biz.MemoGroupJdbcImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

/**
 * * Author: secondriver
 * * Created: 2018/6/23
 */
public class MemoApplication {
    
    public static void main(String[] args) {
        
        ApplicationContext applicationContext=new ClassPathXmlApplicationContext("ApplicationContext.xml");
        
        MemoGroupJdbc memoGroupJdbc = applicationContext.getBean(MemoGroupJdbcImpl.class);
        
        List<MemoGroup> memoGroupList = memoGroupJdbc.queryMemoGroup(1);
        System.out.println(memoGroupList);
    }
}